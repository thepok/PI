# T146 primary-source pins

Audit date: 2026-08-12 UTC. Exactly three primary PDFs were inspected across
three authorized domains. All are reused from the accepted T136 source audit;
the reuse is intentional and disclosed. `pdftotext -layout` produced searchable
text, no OCR was used, and no retrieval failed.

## S0: spectral theory of regular sequences

- Domain: Mahler or functional-equation constants.
- Michael Coons, James Evans, and Neil Manibo, *Spectral Theory of Regular
  Sequences*, Documenta Mathematica 27 (2022), 629--653.
- DOI: <https://doi.org/10.4171/DM/880>.
- PDF: <https://content.ems.press/assets/public/full-texts/serials/dm/27/8965811/online/10.4171-dm-880.pdf>.
- Delivered file: `coons-evans-manibo-10.4171-dm-880.pdf`.
- SHA-256:
  `4badf20c29df7d19695675f6aa677b7e609d763c926ff99f30123bfe29fcf034`.
- Printed p. 632, Definition 1: primitive real-valued `k`-regular sequences,
  nonnegative digit matrices, and positive matrix sum.
- Printed p. 636, Corollary 2 and equation (10): exact finite Fourier-vector
  recursion for every integer frequency and `n>=1`.
- Printed pp. 643--644, Theorem 5: unique dominant eigenvalue,
  joint-spectral-radius gap, growth condition, and Holder regularity for every
  `alpha<log_k(rho/rho_*)`; the paragraph after the proof gives the
  distribution-function caveat.
- Exact replay:
  `pdftotext -f 4 -l 8 -layout coons-evans-manibo-10.4171-dm-880.pdf -`
  and `pdftotext -f 15 -l 17 -layout
  coons-evans-manibo-10.4171-dm-880.pdf -`.

## S1: slow Fourier decay and avoided targets

- Domain: arithmetic or fractal Fourier decay.
- Simon Baker and Amlan Banaji, *Self-Similar and Self-Conformal Measures with
  Slow Fourier Decay*.
- arXiv record: <https://arxiv.org/abs/2602.05593v1>.
- Versioned PDF: <https://arxiv.org/pdf/2602.05593v1>.
- DOI record: <https://doi.org/10.48550/arXiv.2602.05593>.
- Delivered file: `baker-banaji-2602.05593v1.pdf`.
- SHA-256:
  `74d6e8d0192de706c84ad745b8bb9ce478e9735e8891bdbda3a25a4aeb59504d`.
- Printed p. 4, Theorem 1.3: for the explicit Liouville translation described
  there, the three-map ratio-`1/10` self-similar measure is Rajchman but has the
  stated positive inverse-log-log lower envelope at tetrational frequencies.
- Printed p. 5, Theorem 1.7: there exist a decreasing positive `psi` and
  `gamma in (0,1)` with divergent target sum and the stated logarithmic growth,
  while the base-10 return count is zero for every support point and every `N`.
- Printed pp. 18--21, proof of Theorem 1.7 and equations (2.13)--(2.16):
  explicit block construction of `psi` and the avoided target.
- Exact replay:
  `pdftotext -f 4 -l 5 -layout baker-banaji-2602.05593v1.pdf -` and
  `pdftotext -f 18 -l 21 -layout baker-banaji-2602.05593v1.pdf -`.

## S2: character sums with matrix powers

- Domain: short structured exponential sums.
- Alina Ostafe, Igor E. Shparlinski, and Jose Felipe Voloch, *Equations and
  Character Sums with Matrix Powers, Kloosterman Sums over Small Subgroups, and
  Quantum Ergodicity*, International Mathematics Research Notices 2023,
  no. 16, 14196--14238.
- arXiv record: <https://arxiv.org/abs/2110.10941>.
- Versioned PDF: <https://arxiv.org/pdf/2110.10941>.
- DOI: <https://doi.org/10.1093/imrn/rnac226>.
- Delivered file: `ostafe-shparlinski-voloch-2110.10941.pdf`.
- SHA-256:
  `4ecd0a303f6b0c93953a2df1bd011a59e88a281745dfe363865dd6ace562c934`.
- ArXiv PDF p. 6, equation (2.1) and Theorem 2.4: diagonalizable
  `A in GL(d,q)`, the two displayed linear-independence hypotheses, matrix
  order `tau`, determinant order `t`, and the two bounds split at
  `tau=q^(d/2)`.
- ArXiv PDF p. 6, Remark 2.6: twisted sums are covered and standard completion
  gives incomplete sums with an additional `log q` factor.
- ArXiv PDF p. 21 onward, Section 6.1: proof of Theorem 2.4.
- Exact replay:
  `pdftotext -f 6 -l 6 -layout ostafe-shparlinski-voloch-2110.10941.pdf -`
  and `pdftotext -f 21 -l 25 -layout
  ostafe-shparlinski-voloch-2110.10941.pdf -`.

## Claim boundary

The localized source statements are `literature-checked`. Every specialization,
asymptotic comparison, duplicate judgment, and transfer diagnostic in
`REPORT.md` is a `proof sketch`. Neither source states a theorem about the
decimal orbit of pi, canonical A1, C1, or C2.
