# T138 primary-source pins

Audit date: 2026-08-12 UTC. Exactly three primary PDFs were inspected. Each
quoted theorem was checked in the vendored PDF after conversion with
`pdftotext -layout`. PDF page numbers below count from the first PDF page.

## S1: conditional min-entropy and maximal repetition

- Lukasz Debowski, *Maximal Repetition and Zero Entropy Rate*.
- Journal: IEEE Transactions on Information Theory 64(4), 2212--2219 (2018).
- URL: https://arxiv.org/pdf/1609.04683v4
- arXiv landing page: https://arxiv.org/abs/1609.04683
- DOI: https://doi.org/10.1109/TIT.2017.2733535
- File: `debowski-1609.04683v4.pdf`
- SHA-256: `9fe5c1e472f5e78c0cc480fb7a8ae3f7a9b7fa540d8d304a8819ae69386c5af6`
- Exact locator: PDF p. 6, Theorem 2 and equations (22)--(25); definitions
  (13)--(17) begin on PDF p. 5.
- Exact sourced claim and range: for an arbitrary process over a countable
  alphabet, if the conditional block min-entropy satisfies
  `H_inf^cond(k) >= B k` for all sufficiently large `k`, with `B>0`, then
  `L(X_1^n) < A log n` eventually almost surely for every `A>3/B`.
  Equation (24) gives the quantitative union bound
  `P(L(X_1^n)>=k) <= n^2 exp(-H_inf^cond(k))`.

## S2: effective Birkhoff theorem for individual random points

- Laurent Bienvenu, Adam Day, Mathieu Hoyrup, Ilya Mezhirov, Alexander Shen,
  *A constructive version of Birkhoff's ergodic theorem for Martin-Lof random
  points*.
- URL: https://arxiv.org/pdf/1007.5249v2
- arXiv landing page: https://arxiv.org/abs/1007.5249
- DOI: https://doi.org/10.48550/arXiv.1007.5249
- File: `bienvenu-et-al-1007.5249v2.pdf`
- SHA-256: `ba756e24800233d3032b8370270a1a2864a4158e38c63aa699e107cffe9e916d`
- Exact locator: PDF p. 10, Section 3.2, Theorem 8 and its displayed limit;
  Corollary 1 follows on PDF p. 11.
- Exact sourced claim and range: if `mu` is a computable probability measure
  on Cantor space, `T` is a computable almost-everywhere-defined,
  measure-preserving ergodic transformation, and `U` is effectively open, then
  for every Martin-Lof `mu`-random point `omega`, the frequency
  `n^(-1) sum_(k<n) 1_U(T^k omega)` converges to `mu(U)`. The same holds for
  effectively closed sets; Corollary 1 extends it to effectively
  `mu`-approximable sets.

## S3: uniform approximation by restricted powers

- Bo Wang, Bing Li, Ruofan Li, *Uniform Diophantine approximation with
  restricted denominators*.
- URL: https://arxiv.org/pdf/2302.03923v2
- arXiv landing page: https://arxiv.org/abs/2302.03923
- DOI: https://doi.org/10.48550/arXiv.2302.03923
- File: `wang-li-li-2302.03923v2.pdf`
- SHA-256: `278dca3331322b1a64d34fb04651e131e7eb3a6482b5be5b69e9db29d39670ad`
- Exact locator: PDF p. 5 defines `v_hat_(b,A)`; PDF p. 6, Theorem 1.1 gives
  the `eta=1` dimension formula; Theorems 1.2--1.3 on pp. 6--7 treat
  `eta>1`.
- Exact sourced claim and range used here: for integer `b>=2` and a strictly
  increasing sequence `A=(a_n)` with `eta=limsup a_(n+1)/a_n=1`, the set of
  irrationals with restricted-power uniform exponent at least `v_hat`, and the
  exact-exponent set, both have Hausdorff dimension
  `((1-v_hat)/(1+v_hat))^2` for every `v_hat in [0,1]`. The exponent means that
  for every sufficiently large `N`, some `n<=N` obeys
  `||b^(a_n) xi|| < (b^(a_N))^(-v_hat)`.

## Citation boundary

These three theorem statements are `literature-checked`. The substitutions,
finite collision calculations, novelty comparisons, and transfer assessments
in `REPORT.md` are `proof sketch`. The replay is an `experiment` checking
pins and finite arithmetic only.
